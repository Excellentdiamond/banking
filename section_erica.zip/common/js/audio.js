/* BEGIN Howler  Test Script ----------------*/
/* instantiate howler and assign sound files */

/*var test_1 = new Howl({
	src: ["audio/test_1.mp3"]
});

var test_2 = new Howl({
	src: ["audio/test_2.mp3"]
});

var test_3 = new Howl({
	src: ["audio/test_3.mp3"]
});*/


/* play sounds functions */

/*function audio_test_1(){
	test_1.play();	
}

function audio_test_2(){
	test_2.play();	
}


function audio_test_3(){
	test_3.play();	
}*/

/* END Howler  Test Script ----------------*/

